#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char *argv[])
{
    if (check_operation_type(argv) == e_encode) //function call to check operation type
    {
        printf("Selected encoding\n");
        EncodeInfo structure_for_encoding;
        if (read_and_validate_encode_args(argv, &structure_for_encoding) == e_success)
	{
	    printf("Read and validate encode arguments is a success\n");
	    if (do_encoding(&structure_for_encoding) == e_success) //function call to perform encoding
		printf("Encoding is successful\n");
	    else
		printf("Encoding was not successful\n");
	}
	else
	    printf("Read and vaidate encode arguments is a failure\n");
    }
    else if (check_operation_type(argv) == e_decode)
    {
        printf("Selected decoding\n");
	DecodeInfo structure_for_decoding;
	if (read_and_validate_decode_args(argv, &structure_for_decoding) == e_success)
	{
	    printf("Read and validate decode arguments is a success\n");
	    if (do_decoding(&structure_for_decoding) == e_success) //function call to perform decoding
		printf("Decoding is successful\n");
	    else
		printf("Decoding was not successful\n");
	}
	else
	    printf("Read and vaidate decode arguments is a failure\n");
    }
    else
        printf("Invalid argument\nFor encoding : ./a.out -e beautiful.bmp secret.txt [stego.bmp]\nFor decoding : ./a.out -d stego.bmp [decode.txt]\n");
}

OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0)
        return e_encode;
    else if (strcmp(argv[1], "-d") == 0)
        return e_decode;
    else
        return e_unsupported;
}

