/*
Name: Jisha Martha Rodrigues
Date: 11-09-2024
Description: decode.c
*/

#include <stdio.h>
#include "decode.h"
#include "types.h"
#include "common.h"

Status open_files_dec(DecodeInfo *decInfo)
{
    // Src Image file
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    decInfo->fptr_secret = fopen(decInfo->secret_fname, "w");
    // Do Error handling
    if (decInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if (strcmp(strstr(argv[2], "."), ".bmp") == 0)
        decInfo->src_image_fname = argv[2];
    else
        return e_failure;

    if (argv[3] != NULL)
        decInfo->secret_fname = argv[3];
    else
        decInfo->secret_fname = "decode.txt";

    return e_success;
}

Status decode_magic_string(char *magic_string, DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_src_image, 54, SEEK_SET);
    decode_data_from_image(strlen(magic_string), decInfo);
    fseek(decInfo->fptr_src_image, 54, SEEK_SET);
    char str[strlen(magic_string) + 1];
    int i;
    for (i = 0; i < strlen(magic_string); i++)
    {
        fread(decInfo->image_data, 8, 1, decInfo->fptr_src_image);
        decode_byte_from_lsb(decInfo->image_data, &str[i]);
    }
    str[i] = '\0';
    if (strcmp(str, magic_string) == 0)
	return e_success;
    else
	return e_failure;
}

Status decode_data_from_image(int size, DecodeInfo *decInfo)
{
    for (int i = 0; i < size; i++)
    {
        fread(decInfo->image_data, 8, 1, decInfo->fptr_src_image);
        decode_byte_from_lsb(decInfo->image_data, decInfo->char_data);
        fwrite(decInfo->char_data, 1, 1, decInfo->fptr_secret);
    }
}

Status decode_byte_from_lsb(char *image_buffer, char *char_buffer)
{
    *char_buffer = 0x00;
    for (int i = 0; i < 8; i++)
    {
        *char_buffer = ((image_buffer[i] & 0x01) << (7 - i)) | *char_buffer;
    }
}

Status decode_size_from_lsb(char *image_buffer, uint *size)
{
    *size = 0;
    for (int i = 0; i < 32; i++)
    {
        *size = ((image_buffer[i] & 0x01) << (31 - i)) | *size;
    }
}

Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    fread(decInfo->image_data, 32, 1, decInfo->fptr_src_image);
    decode_size_from_lsb(decInfo->image_data, &decInfo->extn_secret_file_size);
    return e_success;
}

Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    decode_data_from_image(decInfo->extn_secret_file_size, decInfo);
    return e_success;
}

Status decode_secret_file_size(DecodeInfo *decInfo)
{
    fread(decInfo->image_data, 32, 1, decInfo->fptr_src_image);
    decode_size_from_lsb(decInfo->image_data, &decInfo->secret_file_size);
    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_secret, 0, SEEK_SET);
    decode_data_from_image(decInfo->secret_file_size, decInfo);
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    if (open_files_dec(decInfo) == e_success)
    {
        printf("Successfully opened all the files\n");
	if (decode_magic_string(MAGIC_STRING, decInfo) == e_success)
	{
	    printf("Magic string decoded successfully\n");
	    if (decode_secret_file_extn_size(decInfo) == e_success)
	    {
		printf("Decoding secret file extn size is a success\n");
		if (decode_secret_file_extn(decInfo) == e_success)
		{
		    printf("Decoded secret file extn successfully\n");
		    if (decode_secret_file_size(decInfo) == e_success)
		    {
			printf("Decoded secret file size successfully\n");
			if (decode_secret_file_data(decInfo) == e_success)
			{
			    printf("Decoded secret file data successfully\n");
			}
			else
			{
			    printf("Failed to decode secret file data\n");
			    return e_failure;
			}
		    }
		    else
		    {
			printf("Failed to decode secret file size\n");
			return e_failure;
		    }
		}
		else
		{
		    printf("Failed to decode secret file extn\n");
		}
	    }
	    else
	    {
		printf("Failed to decode secret file extn size\n");
		return e_failure;
	    }
	}
	else
	{
	    printf("Magic string was not decoded\n");
	    return e_failure;
	}
    }
    else
    {
	printf("Failed to open the required files\n");
        return e_failure;
    }
    return e_success;
}

